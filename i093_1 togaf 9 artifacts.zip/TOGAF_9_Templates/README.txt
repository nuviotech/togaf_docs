
The Open Group TOGAF 9 templates
Copyright (c) 2010, The Open Group

The Open Group gratefully acknowledges Capgemini for contributing these
templates.

Permission is granted for these templates to be used for any purpose.
These templates are provided "as is" without any express or implied
warranties.

TOGAF is a registered trademark of The Open Group.

